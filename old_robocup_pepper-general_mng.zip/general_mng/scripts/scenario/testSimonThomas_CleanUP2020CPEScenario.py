__author__ = 'Simon ERNST & Thomas CURE'


import rospy
import collections

from AbstractScenario import AbstractScenario
from AbstractScenarioAction import AbstractScenarioAction
from AbstractScenarioBus import AbstractScenarioBus
from AbstractScenarioService import AbstractScenarioService
from LocalManagerWrapperV2 import LocalManagerWrapperPalbator
import sys
import json
import time
import math
from copy import deepcopy
from std_msgs.msg import String
from actionlib_msgs.msg import GoalStatus


# class CleanUp2020CPEScenario(AbstractScenario, AbstractScenarioBus, AbstractScenarioAction, AbstractScenarioService):


class CleanUp2020CPEScenario(object):

    def __init__(self,config):

        self._lm_wrapper = LocalManagerWrapperPalbator()
        self.ws = "/home/student/Bureau/workspace_palbator_dev"

        with open("{0}/src/HriManager/scripts/templates/public/json/cleanup/clean_up_test.json".format(self.ws)) as data:
            self._scenario = json.load(data)
            self._scenario['name']='clean_up'

        rospy.loginfo("{class_name}: JSON FILES LOADED.".format(class_name=self.__class__))


        self.rate=rospy.Rate(0.25)
        self.NO_TIMEOUT=1.0

        self.Room_to_clean = None


    def startScenario(self):   
        rospy.loginfo("""
        ######################################
        Starting the {scenario_name} Scenario...
        ######################################
        """.format(scenario_name=self._scenario["name"]))
        self.restart_order=False
        self.steps = deepcopy(self._scenario["steps"])

        rospy.loginfo("SCN : WAITING FOR ACTION SERVER ACTIVATION")
        self._lm_wrapper.client_action_GmToHri.wait_for_server()

        rospy.loginfo("SCN : LOADING CONFIG FOR SCENARIO")
        self._lm_wrapper.timeboard_send_steps_list(self.steps, self._scenario["name"], self.NO_TIMEOUT)


        self.current_index_scenario=0
        while self.current_index_scenario<len(self.steps) and not rospy.is_shutdown():
            
            rospy.loginfo("SCN : CURRENT STEP INDEX : "+str(self.current_index_scenario))
            rospy.loginfo("NEW STEP")

            self.current_step=deepcopy(self.steps[self.current_index_scenario])

            if self.current_step['action']!="":
                result=self.action_parser(self.current_step['action'])
                
                rospy.loginfo("SCN : RESULT FROM PARSER "+str(result))
            else:
                result=self._lm_wrapper.timeboard_set_current_step(self.current_index_scenario,self.NO_TIMEOUT)[1]
                rospy.loginfo("SCN : RESULT WITHOUT PARSER "+str(result))
            
            if result is None:
                rospy.logwarn("SCN : ACTION ABORTED")
                break
            
            elif result != None:
                if 'result' in result and result['result']=="PREEMPTED": 
                    rospy.logwarn("SCN : ACTION ABORTED")
                    break
                
                if result['NextIndex']!="":
                    self.current_index_scenario=deepcopy(result['NextIndex'])
                # elif result['NextIndex']=="" and result['actionName']=="RESTART HRI":
                #     rospy.loginfo("SCN : RESTART HRI request")
                #     break

                if 'saveData' in result:
                    self.Room_to_clean = result['saveData']['where']
                    # self.write_in_JSON()


    def initScenario(self):
        self._enableNavAction = True
        self._enableTtsAction = False
        self._enableDialogueAction = False
        self._enableAddInMemoryAction = False
        self._enableObjectDetectionMngAction = True
        self._enableLookAtObjectMngAction = True
        self._enableMultiplePeopleDetectionAction = False
        self._enableRequestToLocalManagerAction = True
        self._enableLearnPeopleMetaAction = True
        self._enableGetPeopleNameAction = True

        self._enableMoveHeadPoseService = True
        self._enableMoveTurnService = True
        self._enablePointAtService = True
        self._enableResetPersonMetaInfoMapService = True
        self._enableReleaseArmsService = True

    def action_parser(self,stepAction):
        rospy.loginfo('-------------------------')
        rospy.loginfo('using parser')
        rospy.loginfo('***********')
        switcher = {
        "foundObject": self.gm_found_object,
        "catchObject": self.gm_catch_object,
        "goTo": self.gm_go_to,
        "storeObject": self.gm_store_object,
        "releaseObject": self.gm_release_object,
        "openDoor": self.gm_open_door,
        }
        # Get the function from switcher dictionary
        func = switcher.get(stepAction, lambda: "Invalid action")
        
        return func(self.current_index_scenario)

    def gm_found_object(self,stepIndex):
        rospy.loginfo("SCN ACTION FOUND OBJECT")
        return self._lm_wrapper.timeboard_set_current_step(stepIndex,self.NO_TIMEOUT)[1]


    def gm_catch_object(self,stepIndex):
        rospy.loginfo("SCN ACTION CATCH OBJECT")
        return self._lm_wrapper.timeboard_set_current_step(stepIndex,self.NO_TIMEOUT)[1]
    
    def gm_go_to(self,stepIndex):
        rospy.loginfo("SCN ACTION GO TO OBJECT")
        return self._lm_wrapper.timeboard_set_current_step(stepIndex,self.NO_TIMEOUT)[1] 
    
    def gm_store_object(self,stepIndex):
        rospy.loginfo("SCN ACTION STORE OBJECT")
        return self._lm_wrapper.timeboard_set_current_step(stepIndex,self.NO_TIMEOUT)[1] 
    
    def gm_release_object(self,stepIndex):
        rospy.loginfo("SCN ACTION RELEASE OBJECT")
        return self._lm_wrapper.timeboard_set_current_step(stepIndex,self.NO_TIMEOUT)[1]

    def gm_open_door(self,stepIndex):
        rospy.loginfo("SCN ACTION OPEN DOOR OBJECT")
        return self._lm_wrapper.timeboard_set_current_step(stepIndex,self.NO_TIMEOUT)[1]